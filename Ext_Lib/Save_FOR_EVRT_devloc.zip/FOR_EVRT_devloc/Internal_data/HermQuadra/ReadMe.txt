The weights and nodes are obtained from the website:

https://keisan.casio.com/exec/system/1329114617

